<a href="https://proplugins.org"><img src="unmaintained.svg" height="30px" width="100%"></a>

# NativeScript-Themes


<p align="center"><a href="https://proplugins.org"><img src="https://proplugins.org/logos/logo.png" width="400"  /></a></p>

This version is completely unsupported and untested on NativeScript 6.  Please upgrade your plugin to the tested, supported and maintained version. 

Documentation for this plugin is located at <a href="https://npm.proplugins.org/-/web/detail/@proplugins/nativescript-themes">here</a>